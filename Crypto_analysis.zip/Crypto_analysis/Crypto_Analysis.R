# 📦 Install and Load Required Packages
install.packages(c("tidyverse", "lubridate", "caret", "class", "scales", 
                   "ggplot2", "Metrics", "e1071", "rpart", "randomForest"))

library(tidyverse)
library(lubridate)
library(caret)
library(class)
library(scales)
library(ggplot2)
library(Metrics)
library(FNN)
library(e1071)
library(rpart)
library(randomForest)

# 📂 Load and Inspect the Dataset
df <- read_csv("Bitcoin.csv")
head(df)
glimpse(df)
summary(df)
anyNA(df)  # Check for missing values

# 🧼 Clean Column Names
names(df) <- make.names(names(df))

# 📉 Select Relevant Features and Rename for Ease
df <- df %>%
  select(Close, Open, High, Low, Vol., NCC..Next.candlestick.color.) %>%
  rename(Volume = Vol.)

# 🛠️ Feature Engineering: Create Lag Features
df <- df %>%
  mutate(
    Close_Lag1 = lag(Close, 1),
    Close_Lag2 = lag(Close, 2),
    Volume_Lag1 = lag(Volume, 1)
  ) %>%
  drop_na()

# 📊 Normalize the Data
normalize <- function(x) { (x - min(x)) / (max(x) - min(x)) }

df_norm <- df %>%
  mutate(across(c(Close, Open, High, Low, Volume, Close_Lag1, Close_Lag2, Volume_Lag1), normalize))

# 📈 Time Series Train-Test Split (80-20)
split_index <- floor(0.8 * nrow(df_norm))
train <- df_norm[1:split_index, ]
test <- df_norm[(split_index + 1):nrow(df_norm), ]

X_train <- train %>% select(Close_Lag1, Close_Lag2, Volume_Lag1)
y_train <- train$Close
X_test <- test %>% select(Close_Lag1, Close_Lag2, Volume_Lag1)
y_test <- test$Close

# 🤖 Train Models
# 1. KNN
knn_model <- knn.reg(train = X_train, test = X_test, y = y_train, k = 5)
knn_pred <- knn_model$pred

# 2. Linear Regression
lm_model <- lm(Close ~ Close_Lag1 + Close_Lag2 + Volume_Lag1, data = train)
lm_pred <- predict(lm_model, newdata = test)

# 3. Decision Tree
tree_model <- rpart(Close ~ Close_Lag1 + Close_Lag2 + Volume_Lag1, data = train)
tree_pred <- predict(tree_model, newdata = test)

# 4. Random Forest
rf_model <- randomForest(Close ~ Close_Lag1 + Close_Lag2 + Volume_Lag1, data = train, ntree = 100)
rf_pred <- predict(rf_model, newdata = test)

# 5. Support Vector Regression
svr_model <- svm(Close ~ Close_Lag1 + Close_Lag2 + Volume_Lag1, data = train)
svr_pred <- predict(svr_model, newdata = test)

# 📏 Evaluation Metrics Function
R2_Score <- function(y_true, y_pred) {
  ss_res <- sum((y_true - y_pred)^2)
  ss_tot <- sum((y_true - mean(y_true))^2)
  return(1 - (ss_res / ss_tot))
}

evaluate_model <- function(actual, predicted) {
  data.frame(
    MAE = mae(actual, predicted),
    MSE = mse(actual, predicted),
    RMSE = rmse(actual, predicted),
    R2 = R2_Score(actual, predicted),
    MAPE = mape(actual, predicted)
  )
}

# 🧪 Initial Evaluation
results <- rbind(
  KNN = evaluate_model(y_test, knn_pred),
  Linear_Regression = evaluate_model(y_test, lm_pred),
  Decision_Tree = evaluate_model(y_test, tree_pred),
  Random_Forest = evaluate_model(y_test, rf_pred),
  SVR = evaluate_model(y_test, svr_pred)
)
print("🔍 Initial Model Performance:")
print(results)

# 📈 Prediction Plot: Linear Regression
results_plot <- tibble(Index = 1:length(y_test), Actual = y_test, Predicted = lm_pred)

ggplot(results_plot, aes(x = Index)) +
  geom_line(aes(y = Actual, color = "Actual Price"), linewidth = 1) +
  geom_line(aes(y = Predicted, color = "Predicted Price"), linewidth = 1) +
  labs(title = "Actual vs Predicted Prices using Linear Regression",
       y = "Normalized Price", x = "Time Index", color = "") +
  theme_minimal(base_size = 14)

# 🔧 Hyperparameter Tuning

# 1. Tune K for KNN
mae_values <- c()
for (k in 1:20) {
  model <- knn.reg(train = X_train, test = X_test, y = y_train, k = k)
  mae_values[k] <- mae(y_test, model$pred)
}
best_k <- which.min(mae_values)
cat("Best k for KNN:", best_k, "\n")

# 2. Random Forest (already tuned with default 100 trees)
rf_best_pred <- predict(rf_model, newdata = test)

# 3. Tune SVR
svr_tune <- tune(svm, Close ~ ., data = train, ranges = list(cost = 2^(2:5), gamma = 2^(-1:-3)))
best_svr <- svr_tune$best.model
svr_pred_best <- predict(best_svr, newdata = test)

# 4. Retrain Best KNN
knn_best <- knn.reg(train = X_train, test = X_test, y = y_train, k = best_k)
knn_pred_best <- knn_best$pred

# 🏁 Final Evaluation After Tuning
final_results <- rbind(
  KNN_Tuned = evaluate_model(y_test, knn_pred_best),
  Linear_Regression = evaluate_model(y_test, lm_pred),
  Decision_Tree = evaluate_model(y_test, tree_pred),
  Random_Forest_Tuned = evaluate_model(y_test, rf_best_pred),
  SVR_Tuned = evaluate_model(y_test, svr_pred_best)
)

print("✅ Final Performance After Tuning:")
print(final_results)

# 📊 Bar Plot: Performance Comparison
final_results %>%
  rownames_to_column("Model") %>%
  pivot_longer(cols = -Model, names_to = "Metric", values_to = "Value") %>%
  ggplot(aes(x = Model, y = Value, fill = Metric)) +
  geom_col(position = "dodge") +
  labs(title = "📊 Model Comparison Across Performance Metrics", y = "Metric Value") +
  theme_minimal(base_size = 13) +
  theme(axis.text.x = element_text(angle = 25, hjust = 1))
